import React from 'react';

function TestApproval() {
    return (
        <div>
            <h2>테스트 승인 페이지</h2>
            {/* 여기에 승인 관련 UI 추가 */}
        </div>
    );
}

export default TestApproval;