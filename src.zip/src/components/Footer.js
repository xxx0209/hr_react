function Footer() {
    return (            
            <footer className="bg-dark text-white text-center py-3 mt-auto">
                ⓒ 2025 MyCompany. All rights reserved.
            </footer>
    );
}

export default Footer;
